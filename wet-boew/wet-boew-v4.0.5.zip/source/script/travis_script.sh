#!/bin/bash -e

scss-lint .
grunt travis
