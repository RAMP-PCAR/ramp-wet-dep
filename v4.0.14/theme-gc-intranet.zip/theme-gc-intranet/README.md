theme-gc-intranet
===============
[![Build Status](https://travis-ci.org/wet-boew/theme-gc-intranet.svg?branch=master)](https://travis-ci.org/wet-boew/theme-gc-intranet)
[![devDependency Status](https://david-dm.org/wet-boew/theme-gc-intranet/dev-status.svg)](https://david-dm.org/wet-boew/theme-gc-intranet#info=devDependencies)

Government of Canada (GC) Web Usability intranet theme for the Web Experience Toolkit
