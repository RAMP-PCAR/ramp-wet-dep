theme-gcwu-fegc
===============

[![Build Status](https://travis-ci.org/wet-boew/theme-gcwu-fegc.svg?branch=master)](https://travis-ci.org/wet-boew/theme-gcwu-fegc)
[![devDependency Status](https://david-dm.org/wet-boew/theme-gcwu-fegc/dev-status.svg)](https://david-dm.org/wet-boew/theme-gcwu-fegc#info=devDependencies)

Government of Canada (GC) Web Usability theme for the Web Experience Toolkit
