# Contributor guidelines - Web Experience Toolkit (WET)

## WET v4.0

* [Creating a pull request](http://wet-boew.github.io/wet-boew/docs/pull-en.html)

## WET v3.1

* [Developing for WET](http://wet-boew.github.io/v3.1-ci/docs/gs-cd/dev-en.html)
  * [Contributor guidelines](http://wet-boew.github.io/v3.1-ci/docs/gs-cd/contrib-en.html)

-------------------------------------------------------------------

# Lignes directrices pour les contributeurs - Boîte à outils de l’expérience Web (BOEW)

## WET v4.0

* [Créer un &#171;&#160;pull request&#160;&#187;](http://wet-boew.github.io/wet-boew/docs/pull-fr.html)

## WET v3.1

* [Développer pour la BOEW](http://wet-boew.github.io/v3.1-ci/docs/gs-cd/dev-fr.html)
  * [Lignes directrices pour les contributeurs](http://wet-boew.github.io/v3.1-ci/docs/gs-cd/contrib-fr.html)